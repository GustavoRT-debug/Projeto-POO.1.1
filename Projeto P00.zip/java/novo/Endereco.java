package novo;

import java.io.FileWriter;
import java.io.PrintStream;
import java.io.PrintWriter;

public class Endereco {

        private String bairro;
        private String cep;

    public Endereco(String bairro, String cep) {

    }

    //MÉTODOS ACESSORES
    public String getBairro() {
        return bairro;
    }
    public void setBairro(String bairro) {
        this.bairro = bairro;
    }
    public String getCep() {
        return cep;
    }
    public void setCep(String cep) {
        this.cep = cep;
    }

    }

